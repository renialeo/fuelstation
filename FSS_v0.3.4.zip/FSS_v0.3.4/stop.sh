#!/bin/bash
DIRECTORY=`dirname $0`
echo $DIRECTORY

DIR=$DIRECTORY
if [ "$DIR" == "" ] ; then
	HOME=$(pwd)
else
	HOME=$DIR
fi
PIDFILE=$HOME/pid

if [ -f $PIDFILE ] ; then
	kill `cat $PIDFILE`
	rm $PIDFILE
	echo "stop"
else
	echo "Error: unable to find pid file"
fi


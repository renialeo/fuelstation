self.__precacheManifest = [
  {
    "revision": "9421ca238aa09043a7bff12ebd049fc2",
    "url": "manifest.json"
  },
  {
    "revision": "b79e965d5f2592e7ad19",
    "url": "main.b79e965d.js"
  },
  {
    "revision": "bdd984e4ff33e419be53f5b725c32ec9",
    "url": "index.html"
  }
];
DIRECTORY=`dirname $0`
echo $DIRECTORY

INIFILEDIR=$1
HOMEDIR=$DIRECTORY
cd $DIRECTORY

if [ "$HOMEDIR" == "" ] ; then
	HOME=$(pwd)
else 
	HOME=$HOMEDIR
fi
LOG=$INIFILEDIR/logs
LOGFILE=$INIFILEDIR/logs/log.txt
EXEFILE=$HOME/fss
pid="pid"


if [ "$INIFILEDIR" == "" ] ; then
	echo "Error:no data directory"
	exit 0
fi

if [ ! -d $INIFILEDIR ] ; then
	echo "Error:invalid data directory"
	exit 0
else
	OPTION="-fss-config=$INIFILEDIR"
fi

if [ ! -d $LOG ] ; then
	mkdir $LOG
fi
 	
if [ -f $HOME/$pid ] ; then
	echo "pid file exists. unable to start."
else
	$EXEFILE $OPTION >> $LOGFILE 2>&1 &
	echo $!>$HOME/pid
	echo "started"
fi

